# typewriter
A jQuery plugin for displaying text using a typewriter effect.

### Download, instructions and examples
[ryanjairam.com/typewriterjs](http://ryanjairam.com/typewriterjs)
